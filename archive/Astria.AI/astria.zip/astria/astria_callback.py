from fastapi import APIRouter, Request
import logging
import asyncio
from telebot.async_telebot import AsyncTeleBot
from frontend_bot.services.avatar_manager import find_avatar_by_tune_id, mark_avatar_ready
from frontend_bot.handlers.general import bot  # Импортируем объект бота

router = APIRouter()

@router.post("/astria-callback")
async def astria_callback(request: Request):
    data = await request.json()
    tune_id = data.get("id") or data.get("tune_id")
    status = data.get("status")
    logging.info(f"Astria callback received: tune_id={tune_id}, status={status}, data={data}")

    # 1. Найти user_id, avatar_id, title по tune_id
    result = find_avatar_by_tune_id(tune_id)
    if not result:
        logging.error(f"Avatar with tune_id={tune_id} not found!")
        return {"ok": False, "error": "Avatar not found"}
    user_id, avatar_id, title = result

    # 2. Пометить аватар как готовый и добавить в меню
    mark_avatar_ready(user_id, avatar_id)

    # 3. Отправить уведомление пользователю
    text = f"🎉 Обучение аватара '{title}' завершено! Теперь он доступен в вашем меню."
    try:
        await bot.send_message(user_id, text)
        logging.info(f"Notification sent to user_id={user_id} for tune_id={tune_id}")
    except Exception as e:
        logging.error(f"Failed to send Telegram message: {e}")

    return {"ok": True}
