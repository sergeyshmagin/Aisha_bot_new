import os
import aiohttp
from typing import Optional, Dict, Any

ASTRIA_API_URL = "https://api.astria.ai/v1"
ASTRIA_API_KEY = os.getenv("ASTRIA_API_KEY")


class AstriaAPIError(Exception):
    pass


class AstriaService:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or ASTRIA_API_KEY
        if not self.api_key:
            raise ValueError(
                "API ключ Astria не найден. "
                "Установите переменную окружения ASTRIA_API_KEY."
            )
        self.base_url = ASTRIA_API_URL
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

    async def create_tune(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Создать объект tune (тонкая настройка)."""
        url = f"{self.base_url}/tunes"
        async with aiohttp.ClientSession() as session:
            async with session.post(
                url, json=data, headers=self.headers
            ) as resp:
                if resp.status != 200:
                    raise AstriaAPIError(
                        f"Ошибка создания tune: {resp.status} "
                        f"{await resp.text()}"
                    )
                return await resp.json()

    async def create_prompt(
        self, tune_id: str, data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Создать prompt для генерации изображения."""
        url = f"{self.base_url}/tunes/{tune_id}/prompts"
        async with aiohttp.ClientSession() as session:
            async with session.post(
                url, json=data, headers=self.headers
            ) as resp:
                if resp.status != 200:
                    raise AstriaAPIError(
                        f"Ошибка создания prompt: {resp.status} "
                        f"{await resp.text()}"
                    )
                return await resp.json()

    async def get_prompt(self, prompt_id: str) -> Dict[str, Any]:
        """Получить информацию о prompt (статус, результат)."""
        url = f"{self.base_url}/prompts/{prompt_id}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=self.headers) as resp:
                if resp.status != 200:
                    raise AstriaAPIError(
                        f"Ошибка получения prompt: {resp.status} "
                        f"{await resp.text()}"
                    )
                return await resp.json() 